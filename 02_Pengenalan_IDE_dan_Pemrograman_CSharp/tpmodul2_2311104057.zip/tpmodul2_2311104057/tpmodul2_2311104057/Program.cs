﻿class Program
{
    static void Main()
    {
        // Soal A
        Console.Write("Masukkan satu huruf: ");
        char input = Char.ToUpper(Console.ReadKey().KeyChar); // membaca input dan mengubahnya ke huruf besar
        Console.WriteLine(); // pindah ke baris baru

        if ("AIUEO".Contains(input))
        {
            Console.WriteLine($"Huruf {input} merupakan huruf vokal");
        }
        else
        {
            Console.WriteLine($"Huruf {input} merupakan huruf konsonan");
        }

        // Soal B
        int[] bilanganGenap = new int[5];
        for (int i = 0; i < bilanganGenap.Length; i++)
        {
            bilanganGenap[i] = (i + 1) * 2;
        }

        // menampilkan array
        for (int i = 0; i < bilanganGenap.Length; i++)
        {
            Console.WriteLine($"Angka genap {i + 1} : {bilanganGenap[i]}");
        }
    }
}
