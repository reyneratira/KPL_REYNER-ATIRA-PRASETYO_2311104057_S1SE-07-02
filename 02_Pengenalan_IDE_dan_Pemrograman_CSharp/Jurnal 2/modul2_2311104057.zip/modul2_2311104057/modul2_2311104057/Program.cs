﻿class Program
{
    static void Main()
    {
        // Soal A
        Console.Write("Masukkan nama Anda : ");
        string nama = Console.ReadLine();
        Console.WriteLine($"Selamat datang, {nama}!");

        // Soal B
        int size = 50;
        int[] arr = new int[size];

        for (int i = 0; i < size; i++)
        {
            arr[i] = i;
        }

        for (int i = 0; i < size; i++)
        {
            Console.Write($"{arr[i]}");
            if (i % 2 == 0 && i % 3 == 0)
            {
                Console.WriteLine(" #$#$");
            }

            else if (i % 2 == 0)
            {
                Console.WriteLine(" ##");
            }
            else if (i % 3 == 0)
            {
                Console.WriteLine(" $$");
            }
            else
            {
                Console.WriteLine();
            }
        }

        // Soal C
        int nilaiInt;
        
        while(true)
        {
            Console.Write("/Masukkan angka antara 1 sampai 1000 : ");
            string nilaiStr = Console.ReadLine();

            nilaiInt = Convert.ToInt32(nilaiStr);

            if (nilaiInt >= 1 && nilaiInt <= 1000)
                break;

            else
                Console.WriteLine("Angka harus antara 1 - 1000.");

        }

        bool isPrime = true;
        if (nilaiInt == 1)
            isPrime = false;
        else
        {
            for (int i = 2; i <= nilaiInt / 2; i++)
            {
                if (nilaiInt % i == 0)
                {
                    isPrime = false;
                    break;
                }
            }
        }

        if (isPrime)
            Console.WriteLine($"{nilaiInt} adalah bilangan prima.");
        else
            Console.WriteLine($"{nilaiInt} bukan bilangan prima.");
    }
}